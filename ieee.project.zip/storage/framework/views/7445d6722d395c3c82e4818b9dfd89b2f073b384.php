<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="/create1" method="POST">
<?php echo csrf_field(); ?>
    
    <label for="title">Title:</label>
    <input type="text" name="title" id=""><br>
    <label for="body" >Body:</label>
    <textarea name="body" col="30" rows="10"></textarea>
    <button>Send</button>
</form>
    
</body>
</html><?php /**PATH C:\Users\saif\Desktop\folder\ieee.project\resources\views/form.blade.php ENDPATH**/ ?>